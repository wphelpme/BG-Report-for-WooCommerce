<?php
/**
 * Plugin Name:       BG Report for WooCommerce
 * Plugin URI:        https://github.com/wphelpme/BG-Report-for-WooCommerce
 * Description:       Create Report with XML file for the Bulgarien Law. Export XML file by months.
 * Version:           1.1.1
 * Tags:              Bulgarien Law, XML
 * Requires at least: 1.1.1
 * Tested up to: 5.6
 * Stable tag: 1.1.1
 * Requires PHP: 7.0
 * Author:            tzemtz
 * Author URI:        https://github.com/wphelpme
 * Text Domain:       bg-report-for-woocommerce
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html 
 *
 */
// Do not allow direct access to the file.
if( ! defined( 'ABSPATH' ) ) {
    exit;
}
/**
 * All admin scripts and styles.
 */
	function bg_report_for_woocommerce_admin_scripts() {
		wp_enqueue_script( 'jquery-ui-datepicker' );
		wp_enqueue_script( 'bg-report-for-woocommerce-datepicker', plugin_dir_url(__FILE__) . '/js/datepicker.js' );
		wp_enqueue_style( 'bg-report-for-woocommerce-jquery-ui', plugin_dir_url(__FILE__) . 'css/ui.css' );		
		wp_enqueue_style( 'bg-report-for-woocommerce-admin-css', plugin_dir_url(__FILE__) . '/css/admin.css' );
	}
	add_action( 'admin_enqueue_scripts', 'bg_report_for_woocommerce_admin_scripts');
/**
 * User Section
 */
	add_action( 'admin_menu', 'bg_report_for_woocommerce_menu' );
	function bg_report_for_woocommerce_menu() {
		add_menu_page( 'BG Report', 'BG Report', 'administrator', 'bg_report', 'bg_report_for_woocommerce_settings_page', 'dashicons-calendar-alt' );
	}
	add_action( 'admin_init', 'bg_report_for_woocommerce_plugin_settings' );
	function bg_report_for_woocommerce_plugin_settings() {
	    register_setting( 'bg_report', 'bg_eik' );
	    register_setting( 'bg_report', 'bg_shop_number' );
	    register_setting( 'bg_report', 'domain_name' );
	    register_setting( 'bg_report', 'bg_creation_date' );
	    register_setting( 'bg_report', 'bg_month' );
	    register_setting( 'bg_report', 'bg_year' );
	    register_setting( 'bg_report', 'e_shop_type' );
	    register_setting( 'bg_report', 'vpos_name' );
	}
	function bg_report_for_woocommerce_settings_page() {
	?>
	<div id="report-plugin">		
	    <h1><?php esc_html_e( 'Report', 'bg-report-for-woocommerce' ); ?></h1>
	    <br />
		<form id="bg-report-form" autocomplete="off" action="options.php" method="post" role="form" name="custom-report">
			<?php settings_fields( 'bg_report' ); ?>
			<?php do_settings_sections( 'bg_report' ); ?>
		<table border="1">
			<tr>
				<td><span class="bg-title"><?php esc_html_e( 'Add EIK: ', 'bg-report-for-woocommerce' ); ?></span></td>
				<td><input autocomplete="off" placeholder="<?php esc_html_e('bg_eik', 'bg-report-for-woocommerce'); ?>" name="bg_eik" value="<?php echo esc_html( get_option( 'bg_eik' ) ); ?>" /></td>
			</tr>
			<tr>
				<td><span class="bg-title"><?php esc_html_e( 'E-Shop Number: ', 'bg-report-for-woocommerce' ); ?></span></td>
				<td><input autocomplete="off" placeholder="<?php esc_html_e( 'E-Shop Number', 'bg-report-for-woocommerce' ); ?>" name="bg_shop_number" value="<?php echo esc_html( get_option('bg_shop_number' ) ); ?>" /></td>
            </tr>
			<tr>
				<td><span class="bg-title"><?php esc_html_e( 'Domain Name: ', 'bg-report-for-woocommerce' ); ?></span></td>
				<td><input autocomplete="off" placeholder="<?php esc_html_e( 'mysite.com', 'bg-report-for-woocommerce' ); ?>" name="domain_name" value="<?php echo esc_html( get_option('domain_name') ); ?>" /></td>
	        </tr> 
			<tr> 
				<td>
				<span class="bg-title"><?php esc_html_e('Creation Date: ', 'bg-report-for-woocommerce'); ?></span></td>
				<td><input autocomplete="off" placeholder="<?php esc_html_e( 'Creation Date', 'bg-report-for-woocommerce' ); ?>" type="text" class="datepicker" name="bg_creation_date" value="<?php echo esc_html( get_option( 'bg_creation_date' ) ); ?>" /></td>
			</tr>
			<tr> 
				<td><span class="bg-title"><?php esc_html_e('Month: ', 'bg-report-for-woocommerce'); ?></span></td>
				<td>
					<?php $bg_month = esc_html(get_option('bg_month')); ?>
					<select name="bg_month"  style="width:300px;">
						<option value=""></option>
						<option value="1" <?php if ( $bg_month == "1" ) echo 'selected="selected"'; ?>>01</option>
						<option value="2" <?php if ( $bg_month == "2" ) echo 'selected="selected"'; ?>>02</option>
						<option value="3" <?php if ( $bg_month == "3" ) echo 'selected="selected"'; ?>>03</option>
						<option value="4" <?php if ( $bg_month == "4" ) echo 'selected="selected"'; ?>>04</option>
						<option value="5" <?php if ( $bg_month == "5" ) echo 'selected="selected"'; ?>>05</option>
						<option value="6" <?php if ( $bg_month == "6" ) echo 'selected="selected"'; ?>>06</option>
						<option value="7" <?php if ( $bg_month == "7" ) echo 'selected="selected"'; ?>>07</option>
						<option value="8" <?php if ( $bg_month == "8" ) echo 'selected="selected"'; ?>>08</option>
						<option value="9" <?php if ( $bg_month == "9" ) echo 'selected="selected"'; ?>>09</option>
						<option value="10" <?php if ( $bg_month == "10" ) echo 'selected="selected"'; ?>>10</option>
						<option value="11" <?php if ( $bg_month == "11" ) echo 'selected="selected"'; ?>>11</option>
						<option value="12" <?php if ( $bg_month == "12" ) echo 'selected="selected"'; ?>>12</option>
					</select>
				</td>
			</tr>
			<tr> 
				<td><span class="bg-title"><?php esc_html_e( 'Year: ', 'bg-report-for-woocommerce' ); ?></span></td>
				<td>
					<?php $bg_year = esc_html( get_option('bg_year' ) ); ?>
					<select name="bg_year"  style="width:300px;">
						<option value=""></option>
						<option value="2020" <?php if ( $bg_year == "2020" ) echo 'selected="selected"'; ?>>2020</option>
						<option value="2021" <?php if ( $bg_year == "2021" ) echo 'selected="selected"'; ?>>2021</option>
						<option value="2022" <?php if ( $bg_year == "2022" ) echo 'selected="selected"'; ?>>2022</option>
						<option value="2023" <?php if ( $bg_year == "2023" ) echo 'selected="selected"'; ?>>2023</option>
						<option value="2024" <?php if ( $bg_year == "2024" ) echo 'selected="selected"'; ?>>2024</option>
						<option value="2025" <?php if ( $bg_year == "2025" ) echo 'selected="selected"'; ?>>2025</option>
						<option value="2026" <?php if ( $bg_year == "2026" ) echo 'selected="selected"'; ?>>2026</option>
					</select>
				</td>
			</tr>
			<tr> 
				<td>
				<span class="bg-title"><?php esc_html_e( 'E-Shop Type: ', 'bg-report-for-woocommerce' ); ?></span></td>
				<td><input min="1" max="2" step="1" placeholder="<?php esc_html_e( 'e_shop_type', 'bg-report-for-woocommerce' ); ?>" type="number" min="1" name="e_shop_type" value="<?php echo esc_html( get_option( 'e_shop_type' ) ); ?>" /></td>
			</tr>
			<tr>
				<td><span class="bg-title"><?php esc_html_e( 'Virtual POS Name: ', 'bg-report-for-woocommerce'); ?></span></td>
				<td><input autocomplete="off" placeholder="<?php esc_html_e( 'Virtual POS Name', 'bg-report-for-woocommerce' ); ?>" name="vpos_name" value="<?php echo esc_html( get_option( 'vpos_name' ) ); ?>" /></td>
            </tr>
		</table>	
		    <div class="note-submit"><?php submit_button(); ?></div>
		</form>
		<a href="?page=bg_report&reportme=1"><?php echo esc_html_e( 'Generate Report', 'bg-report-for-woocommerce' ); ?></a>
		<?php if( isset( $_GET['reportme'] ) ) { ?>
		<a href="<?php echo plugin_dir_url(__FILE__) .'reports/report.xml'; ?>" download><?php echo esc_html_e( 'Download Report', 'bg-report-for-woocommerce' ); ?></a>
		<?php } ?>
	</div>
	<?php
	function bg_report_for_woocommerce_language_load() {
		load_plugin_textdomain( 'bg-report-for-woocommerce', false, basename( dirname(__FILE__) ) . '/languages' );
	}
	add_action('init', 'bg_report_for_woocommerce_language_load');
/**
 * Get from date to date fixed for one month.
 */		
function bg_report_for_woocommerce_date () {
				
	if (!empty( get_option('bg_month') ) and !empty( get_option('bg_year') ) ) {

		$bg_year = esc_html( get_option('bg_year') );
		$bg_month = "0".esc_html( get_option( 'bg_month') );
		
		if (get_option('bg_month')>9){
			$bg_month = esc_html(get_option( 'bg_month' ) );
		}

		$mont_to = esc_html( get_option( 'bg_month' ) );
		
		if ($mont_to>9){
			$mont_to = ( esc_html( get_option( 'bg_month' )+1) );
		}
		else {
			$mont_to = ( esc_html( get_option( 'bg_month') )+1);
		}
			
		$day = '01';
		$data_from = $bg_year."-".$bg_month."-".$day ;

		if ( get_option( 'bg_month' )==12 ) {
			$bg_year = ( $bg_year+1 );
			$mont_to = "01";
		}
		
		$data_to = $bg_year."-". ( $mont_to ) ."-".$day;
		return $data_from."...".$data_to;
	}
	else {
		return "Select dates from - to.";
	}
}

function bg_report_for_woocommerce_complete_orders () {

	$arr_push_orders = array();
	array_unshift( $arr_push_orders,"" );
	unset( $arr_push_orders[0] );

	$args = array(
		'limit'           => -1,
		'type'        => 'shop_order',
		'date_completed'  => bg_report_for_woocommerce_date (),
		'status'          => 'completed'
	);
	
	$query = new WC_Order_Query( $args );
	$orders = $query->get_orders();

	foreach( $orders as $order_id ) {
		$order = wc_get_order( $order_id );
	
		$arr_push_items = array();
		array_unshift( $arr_push_items, "" );
		unset( $arr_push_items[0] );

		$order_count_arr = array();
		array_unshift($order_count_arr, "");
		unset( $order_count_arr[0] );

		foreach ( $order_id->get_items() as  $item ) {
			$product_name = $item->get_name();
			$item_quantity = $item->get_quantity();
			$item_price = $order->get_item_subtotal( $item);
			$item_tax = $order->get_line_tax( $item );
			$get_total = $item->get_total();
			$item_vat_rate = ( ( $item_tax / $item_price ) * 100 ) / $item_quantity;
			$item_total_price_and_tax = ( $item_price*$item_quantity ) + $item_tax;

			$items_array = array (
				'<artenum>',
					'<art_name>'.$product_name.'</art_name>',// Get product name from the order.
					'<art_quant>'.$item_quantity.'</art_quant>',// Get product quantity from the order.
					'<art_price>'.$item_price.'</art_price>',// Get product single price.
					'<art_vat_rate>'.number_format( (float)$item_vat_rate, 0, '.', '' ).'</art_vat_rate>',// Get item VAT rate from WooCommece -> VAT -> Standart Rates
					'<art_vat>'.$item_tax.'</art_vat>', // Get product TAX.
					'<art_sum>'. number_format( (float)$item_total_price_and_tax, 2, '.', '' ).'</art_sum>',// Get product total price.
					'</artenum>',
				);

			$imp_items_arr = implode( "", $items_array );
			array_push( $arr_push_items, $imp_items_arr );
			
			$order_count = 1;
			$order_count++;
			
			array_push( $order_count_arr, $order_count );
			$itm_count = count( $order_count_arr );
		}
		
		$total_order_vat = $order->get_total_tax();
		$total_order_price = $order->get_subtotal();
		$ord_disc = $order->get_total_discount();

		$orders_array = array('
			<order>',
				'<rorderenum>',
					implode( "", array(
					'<ord_n>'.$order->get_order_number().'</ord_n>', // Get order ID without #
					'<ord_d>'.date( 'Y-m-d', strtotime( $order->get_date_created() ) ).'</ord_d>',
					'<art>'
						.implode( "",$arr_push_items ).
						'<ord_total1>'.$itm_count.'</ord_total1>', // Get items count in the order
						'<ord_disc>'.$ord_disc.'</ord_disc>', // Get order discount
						'<ord_vat>'.$total_order_vat.'</ord_vat>', // Get total order TAX
						'<ord_total2>'.number_format( (float)$total_order_price+$total_order_vat, 2, '.', '' ).'</ord_total2>', // Get total order price
						'<paym>'.$order->get_payment_method_title().'</paym>', // Get payment method. For example direct bank transfer, Paypal, Stripe or other.
						'<pos_n>'.esc_html( get_option( 'vpos_name' )).'</pos_n>', // Get virtual POS Number
						'<trans_n> '.$order->get_transaction_id().'</trans_n>', // Get Transaction Number
						'<proc_id> </proc_id>',
					'</art>',
				'</rorderenum>',
				'</order>'
				)
			)
		);

		$imp_orders_arr = implode( "",$orders_array );
			array_push( $arr_push_orders, $imp_orders_arr );
		}

		$imp_orders = implode( "",$arr_push_orders );
		return $imp_orders;
}


//Show all refunded orders 	
function bg_report_for_woocommerce_refunds () {
	$all_summ = 0;	
    $count = $r_total = $r_ord = "";
	$args = array(
		'limit' => -1,
		'type' => 'shop_order',
		'date_completed' => bg_report_for_woocommerce_date (),
		'status' => 'refunded, completed'
	);
	
	$query = new WC_Order_Query( $args );//Create query with refundend orders and partial refundend orders.
	$orders = $query->get_orders();
								
	$ref_count = array();// Array with count of refunded orders.
	array_unshift( $ref_count, "" );
	unset( $ref_count[0] );
						
	$arr_push_refunds = array();// Array refunded orders in XML. 
	array_unshift( $arr_push_refunds, "" );
	unset( $arr_push_refunds[0] );								

	foreach( $orders as $order_id ) {
		
		$order = wc_get_order( $order_id );	//get orders by $args
		
		if( $order->get_refunds() ) { //check if is refundend orders and partial refundend order.
		
		    array_push( $ref_count, $count );//Array push count of refunds
			$total_order_prices = $order->get_total_refunded();// Get refunded price
			
			$all_summ += $total_order_prices;// Add price for all refunded orders
			
			$r_ord =  '<r_ord> '.count( $ref_count ).'</r_ord>';// Get count of refunds
			$r_total =  '<r_total>'.$all_summ.'</r_total>'; // Get total price for all refunded orders.	

			foreach( $order->get_refunds() as $order_ref ) {
				
				$refund_date = $order_ref->get_date_created()->format( 'Y-m-d' );
				
				$refunds_array = array ( // Array return refunded orders in XML. 
					'<rorder>',
						'<rorderenum>',
							'<r_ord_n>'.$order->get_order_number().'</r_ord_n>',
							'<r_amount>'.$total_order_prices.'</r_amount>',
							'<r_date>'.$refund_date.'</r_date>',
							'<r_paym>'.$order->get_payment_method_title().'</r_paym>',
						'</rorderenum>',
					'</rorder>'
					);
				$imp_refunds_arr = implode( "", $refunds_array ); // Array implode refunded orders in XML.
				array_push( $arr_push_refunds, $imp_refunds_arr );
				
			}
			
		}
	
	}
	
	$imp_orders = implode( "", $arr_push_refunds );
	return $r_ord.$r_total.$imp_orders;
}

	
echo bg_report_for_woocommerce_date ();
 
       $bg_report_xml = '<?xml version="1.0" encoding="WINDOWS-1251"?>
		<audit>
		<eik>'.esc_html( get_option('bg_eik' ) ).'</eik>
		<e_shop_n>'.esc_html( get_option('bg_shop_number' ) ).'</e_shop_n>
		<domain_name>'.esc_html( get_option('domain_name' ) ).'</domain_name>
		<creation_date>'.esc_html( get_option('bg_creation_date' ) ).'</creation_date>
		<mon>'.esc_html( get_option( 'bg_month' ) ).'</mon>
		<god>'.esc_html( get_option( 'bg_year' ) ).'</god>
		<e_shop_type>'.esc_html( get_option( 'e_shop_type' ) ).'</e_shop_type>
		'.bg_report_for_woocommerce_complete_orders ().
		 bg_report_for_woocommerce_refunds ().'
		</audit>
		';
		
		function ru2Lat($string) {
			$rus = array('ё','ж','ц','ч','ш','щ','ю','я','Ё','Ж','Ц','Ч','Ш','Щ','Ю','Я');
			$lat = array('yo','zh','tc','ch','sh','sh','yu','ya','YO','ZH','TC','CH','SH','SH','YU','YA');
			$string = str_replace($rus,$lat,$string);
			$string = strtr($string,
			 "АБВГДЕЗИЙКЛМНОПРСТУФХЪЫЬЭабвгдезийклмнопрстуфхъыьэ",
			 "ABVGDEZIJKLMNOPRSTUFH_I_Eabvgdezijklmnoprstufh'i'e");

		return($string);
		}

		function bg_report_for_woocommerce_transliterate($string){
			if (!is_string($string)) return $string;
			return ru2lat(mb_convert_encoding($string,'windows-1251'));
		}

		function bg_report_for_woocommerce_array($a){
			$c = array_map(bg_report_for_woocommerce_transliterate,$a);
			return $c;
		}		
		$convert = bg_report_for_woocommerce_transliterate($bg_report_xml);
		
	if( isset( $_GET['reportme'] ) ) {
		$XMLRoot = new SimpleXMLElement( $convert );
		$path_a = plugin_dir_path(__FILE__) .'reports/report.xml';
		if ( file_exists( $path_a) ) {
			unlink( $path_a );
		}
		if ( !file_exists( $path_a ) ) {
			touch( $path_a );
			file_put_contents( $path_a, $XMLRoot->asXML() );
			
			
		}
	}
}