=== BG Report for WooCommerce ===
Contributors: tzemtz
Tags: XML Export, BG, Export XML, Orders
Requires at least: 1.1.2
Tested up to: 5.6
Stable tag: 1.1.2
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Generate BG Report - XML file.

== Description ==

Generate a report with XML file according the Bulgarien Law. Export XML file by months.

* Export XML file.
* Export Complete orders.
* Export Refunded orders.

== Frequently Asked Questions ==

Install via Plugins > Install New
1. Search for "BG Report for WooCommerce"
2. Click the "Install Now" link
3. Click "Activate Plugin"

= A question that someone might have =

Install via Plugins > Install New
1. Search for "BG Report for WooCommerce"
2. Click the "Install Now" link
3. Click "Activate Plugin"


== Screenshots ==

== Changelog ==

=  1.1.2  January  02 2021 =
*FIXED: Check WooCommerce Instalation
*CHANGE: Translation

= 1.1.0 =
*Initial release of plugin - 16 December 2020*

== Upgrade Notice ==


