jQuery(document).ready(function(jQuery) {
    jQuery(".datepicker").datepicker({ dateFormat: "yy-mm-dd" }).val();	
	jQuery(".datepicker").datepicker();
});




