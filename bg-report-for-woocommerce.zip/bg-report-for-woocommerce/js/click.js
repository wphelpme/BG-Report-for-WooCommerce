function clikcMe(){
	document.getElementById('d-report').style.display = 'none';
}
